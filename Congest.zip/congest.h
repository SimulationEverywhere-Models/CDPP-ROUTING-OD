/*******************************************************************
*
*  DESCRIPTION: class congestion
*
*  AUTHOR: Andrea D�az && Ver�nica Vazquez
*
*  EMAIL: mailto://rodiaz@dc.uba.ar
*         mailto://vvazqu@dc.uba.ar
*
*  DATE: 24/01/2000
*
*******************************************************************/

#ifndef __congestion_H
#define __congestion_H

/** include files **/
#include <map.h>
#include "atomic.h"     // class Atomic

class congestion: public Atomic 
{
public:
	congestion( const string &name = "congestion"); // Default Constructor

	virtual string className() const;


protected:
  	Model &initFunction();
	Model &externalFunction(const ExternalMessage & );
	Model &internalFunction(const InternalMessage &);
	Model &outputFunction(const InternalMessage & );

private:
	const Port &IngresaAuto;
	const Port &SaleAuto;
	const Port &PreguntaPeso;
	const Port &peso;
	const Port &stop;

	int cant_autos;



}; // class congestion


// ** inline ** // 
inline
string congestion::className() const
{
	return "congestion" ;
}


#endif   //__CONGESTION_H 