/*******************************************************************
*
*  DESCRIPTION: class Congestion
*
*  AUTHOR: Andrea D�az && Ver�nica Vazquez
*
*  EMAIL: rodiaz@dc.uba.ar		
*  	  vvazqu@dc.uba.ar	
*
*  DATE: 24/01/2000
*
*******************************************************************/

/** include files **/
#include "congest.h"       // base header
#include "message.h"       // class InternalMessage 
#include "mainsimu.h"      // class Simulator
#include "distri.h"        // class Distribution 
#include "strutil.h"       // str2Value( ... )

/*******************************************************************
* Function Name: congestion
* Description: constructor
********************************************************************/
congestion::congestion( const string &name)
	:Atomic(name)
	, IngresaAuto(this->addInputPort("IngresaAuto"))
	, SaleAuto(this->addInputPort("SaleAuto"))
	, PreguntaPeso(this->addInputPort("PreguntaPeso"))
	, stop(this->addInputPort("stop"))
	, peso(this->addOutputPort("peso"))
{
}	
//******************************************************************
Model &congestion::initFunction()
{
  cant_autos = 0;
  holdIn( active, Time::Zero );
  return *this;
}
//******************************************************************
Model &congestion::externalFunction(const ExternalMessage &msg)
{
  if (msg.port() == IngresaAuto )
  {
     cant_autos++;
  }
  if (msg.port() == SaleAuto )
  {
     cant_autos--;
  }
  if (msg.port() == PreguntaPeso )
  {
     holdIn( active, Time::Zero );
  }
  if (msg.port() == stop )
  {
    	this->passivate();
  }

  return *this;
}
//******************************************************************
Model &congestion::outputFunction( const InternalMessage &msg) 
{
	sendOutput(msg.time(), peso, cant_autos );
        return *this ;
}
//******************************************************************
Model &congestion::internalFunction (const InternalMessage &msg)
{
  	passivate();
	return *this;
}
//******************************************************************
