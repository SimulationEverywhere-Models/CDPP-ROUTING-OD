/*******************************************************************
*
*  DESCRIPTION: Simulator::registerNewAtomics()
*
*  AUTHOR: Amir Barylko & Jorge Beyoglonian 
*
*  EMAIL: mailto://amir@dc.uba.ar
*         mailto://jbeyoglo@dc.uba.ar
*
*  DATE: 27/6/1998
*
*******************************************************************/

#include "modeladm.h" 
#include "mainsimu.h"
#include "trafico.h"    // class Trafico
#include "congest.h"    // class congestion
#include "od.h"   	// class od

void MainSimulator::registerNewAtomics() {
	SingleModelAdm::Instance().registerAtomic( NewAtomicFunction<Trafico>() , "Trafico" ) ;
	SingleModelAdm::Instance().registerAtomic( NewAtomicFunction<congestion>() , "congestion" ) ;
	SingleModelAdm::Instance().registerAtomic( NewAtomicFunction<od>() , "od" ) ;
}
