/*******************************************************************
*
*  DESCRIPTION: class OD
*
*  AUTHOR: Andrea D�az && Ver�nica Vazquez
*
*  EMAIL: rodiaz@dc.uba.ar		
*  	  vvazqu@dc.uba.ar	
*
*  DATE: 24/01/2000
*
*******************************************************************/

/** include files **/
#include "od.h"       // base header
#include "message.h"       // class InternalMessage 
#include "mainsimu.h"      // class Simulator
#include "distri.h"        // class Distribution 
#include "strutil.h"       // str2Value( ... )
#include "math.h"    

/*******************************************************************
* Function Name: od
* Description: constructor
********************************************************************/
od::od( const string &name)
	:Atomic(name)
	, SolicitaCamino(this->addInputPort("SolicitaCamino"))
	, stop(this->addInputPort("stop"))
	, InformaCamino(this->addOutputPort("InformaCamino"))
{
}	

//******************************************************************
od::~od()
{
	matriz.erase( matriz.begin(), matriz.end() ) ;
	
        //free( matriz);
	//free( camino);
}
//******************************************************************
Model &od::initFunction()
{
  IniciarMatriz();
  camino = 0;
  holdIn( active, Time::Zero );
  return *this;
}
//******************************************************************
Model &od::externalFunction(const ExternalMessage &msg)
{
  /******************************************************************
   *  En el mensaje recibo el origen, el destino y el proximo tramo *
   *  de la siguiente forma : T.OOODDD, donde                       *
   *  T: proximo tramo						    *
   *  OOO: origen, con ceros a la izquierda de relleno		    *
   *  DDD: destino, con ceros a la izquierda de relleno 	    *
   ******************************************************************/

  list<int> l_camino;
  double l_camino_format = 0;
  int l_origen =0;
  int l_destino =0;
  int l_proximoTramo =0;
  double l_aux = 0;
  double l_value = 0; 	
 
  if (msg.port() == SolicitaCamino )
  {
     l_value = msg.value();
     l_proximoTramo = floor(l_value);  
     l_aux = ( l_value - floor(l_value) ) * pow(10,2); // OOO,DDD
     l_origen = floor(l_aux);  // OOO
     l_aux = (l_aux - floor(l_aux)) * pow(10,2);
     
     // Redondeo
     if ((l_aux - floor(l_aux) ) > 0.5)
   	  l_destino = ceil(l_aux);
     else 		
    	  l_destino = floor(l_aux);
	
     l_camino = ObtenerCamino( l_proximoTramo, l_origen, l_destino); 
     camino =ConvertirCamino(l_camino); 
     holdIn( active, Time::Zero );
  }
  //
  if (msg.port() == stop )
  {
    	this->passivate();
  }

  return *this;
}
//******************************************************************
Model &od::outputFunction( const InternalMessage &msg) 
{
	sendOutput(msg.time(), InformaCamino, camino);
        return *this ;
}
//******************************************************************
Model &od::internalFunction (const InternalMessage &msg)
{
  	passivate();
	return *this;
}

//******************************************************************
void od::IniciarMatriz ()
{
	matrizOD elem;
        string inputFile("od.in");
        FILE *fileIn;
	char line[256];
	char l_origen[10];
	char l_destino[10] ;
	char l_tramo[10];
	char *endptr;
	int i = 0;
	int j = 0;
	int t = 0;
	long long_tramo = 0;
	
        MASSERTMSG(fileIn = fopen (inputFile.c_str(), "r"), "Can't open the input file \n");
        while (fgets (line, 255, fileIn)!= NULL)
	{	
			i=0;
			printf("linea= %s\n", line);
			while(! isdigit(line[i]))
			i++;

			// origen
			j=0;
			while(isdigit(line[i]))
			{
				l_origen[j]= line[i];			
				j++;
				i++;
			}
		
			while(! isdigit(line[i]))
				i++;
		
			// destino
			j=0;
			while(isdigit(line[i]))
			{
				l_destino[j]= line[i];
				j++;
				i++;
			}

			// camino

			elem.camino.erase(elem.camino.begin(), elem.camino.end());
			while((line[i])!= '\n')
			{
				while(! isdigit(line[i]))
					i++;

				//Encuentro un tramo del camino			
				t=0;
				while (isdigit(line[i]))
				{		
					l_tramo[t] = line[i];	
					t++;	
					i++;	
				}
				l_tramo[t]= '\n';
				long_tramo = strtol(l_tramo, &endptr, 0);
				elem.camino.push_back(long_tramo);
			
				}	
	
       			elem.origen= strtol(l_origen, &endptr,0);
			elem.destino= strtol(l_destino, &endptr,0);
		
			matriz.push_back(elem); 

           
	}
	fclose(fileIn);
	
}
//******************************************************************
list<int> od::ObtenerCamino(int pproximo_tramo, int porigen,int pdestino)
{
	Camino l_camino;

	list<matrizOD>::const_iterator cursor( matriz.begin() ) ;
	
	for( ; cursor != matriz.end() ; cursor ++ )
	{
		list<int>::const_iterator cam_cur ( ((*cursor).camino).begin() );

		if ( ( (*cursor).origen == porigen )  &&
 		     ( (*cursor).destino == pdestino ) &&
		     ( *cam_cur  != pproximo_tramo) )
		{
	
		l_camino =   (*cursor).camino;
		}
		
	}
	return (l_camino);
}

//******************************************************************
double od::ConvertirCamino(list<int> p_camino)
{
	double l_camino = 0;
	int i=1;	
	list<int>::const_iterator cursor(p_camino.begin() ) ;
   	
  
	for( ; cursor != p_camino.end() ; ++cursor)
	{
		l_camino = ((*cursor) * pow(10, -(i-1)) ) + l_camino;
		i = i+2;
				
	}
	return (l_camino);
}

