/*******************************************************************
*
*  DESCRIPTION: class OD
*
*  AUTHOR: Andrea D�az && Ver�nica Vazquez
*
*  EMAIL: mailto://rodiaz@dc.uba.ar
*         mailto://vvazqu@dc.uba.ar
*
*  DATE: 02/03/2000
*
*******************************************************************/

#ifndef __OD_H
#define __OD_H

/** include files **/
#include <map.h>
#include <list>
#include <strstream>
#include <fstream>
#include "atomic.h"     // class Atomic

class od: public Atomic 
{
public:
	od( const string &name = "od"); // Default Constructor
	od::~od(); // destructor

	virtual string className() const;

	typedef  list<int> Camino;

	typedef struct  matrizOD
	{ int origen;
	  int destino;
	  Camino camino;
	}; 
	
        list<matrizOD> matriz;

	double camino;
	//

	list<int> ObtenerCamino(int pproximo_tramo, int porigen,int pdestino);

	double ConvertirCamino(list<int>);

	void IniciarMatriz(); 
	
protected:
  	Model &initFunction();
	Model &externalFunction(const ExternalMessage & );
	Model &internalFunction(const InternalMessage &);
	Model &outputFunction(const InternalMessage & );

		
private:
	const Port &SolicitaCamino;
	const Port &InformaCamino;
	const Port &stop;

	

}; // class od


// ** inline ** // 
inline
string od::className() const
{
	return "od" ;
}


#endif   //__OD_H 